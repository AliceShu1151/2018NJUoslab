#ifndef __DEVICE_H__
#define __DEVICE_H__

#include "device/serial.h"
void video_print(int row, int col, char c);
#endif
